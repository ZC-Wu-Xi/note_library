package com.roy.mapper;

import com.baomidou.mybatisplus.core.mapper.BaseMapper;
import com.roy.entity.Course;

/**
 * @author roy
 * @date 2022/3/27
 * @desc
 */
public interface CourseMapper extends BaseMapper<Course> {
}
